package com.techm.daos.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.techm.daos.StoreLocDAO;


public class StoreLocDAOImpl implements StoreLocDAO 
{

	private Connection con;
	private String conURL="jdbc:oracle:thin:@localhost:1521:XE";
	private String dbUserName="system";
	private String dbPassword="system";
	private String driverClass="oracle.jdbc.OracleDriver";
	
	public StoreLocDAOImpl()
	{
		try 
		{
			Class.forName(driverClass);
			System.out.println("Driver Loaded!");
		}
		catch (ClassNotFoundException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
	@Override
	public Connection getConnection() 
	{
	try 
	{
		con=DriverManager.getConnection(conURL,dbUserName,dbPassword);
		System.out.println("connection to DB established!");
	} 
	catch (SQLException e) 
	{
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return con;
	}

	@Override
	public void closeConnection()
	{
		if(con!=null)
		{
			try 
			{
				con.close();
				System.out.println("Connection to DB closed!");
			} 
			catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		

	}

	@Override
	public String getAddresses(String city) 
	{
		String addresses=null;
		String SQL="select addresses from storeloc_tbl where city=?";
		getConnection();
		try 
		{
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, city);
			ResultSet rs=ps.executeQuery();
			//Since multiple records are expected we use while
			if(rs.next())
			{
				addresses=rs.getString("addresses");
			}
			else
			{
				addresses="No addresses found!";
			}	
		} 
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			closeConnection();
		}
		
		return addresses;
	}

}
