package com.techm.daos.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.techm.daos.WriteToUsDAO;
import com.techm.models.Customer;

import com.techm.models.WriteToUs;

public class WriteToUsDAOImpl implements WriteToUsDAO 
{
	private Connection con;
	private String conURL="jdbc:oracle:thin:@localhost:1521:XE";
	private String dbUserName="system";
	private String dbPassword="system";
	private String driverClass="oracle.jdbc.OracleDriver";
	
	public WriteToUsDAOImpl()
	{
		try 
		{
			Class.forName(driverClass);
			System.out.println("Driver Loaded!");
		}
		catch (ClassNotFoundException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	@Override
	public Connection getConnection() 
	{
		try 
		{
			con=DriverManager.getConnection(conURL,dbUserName,dbPassword);
			System.out.println("connection to DB established!");
		} 
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}

	@Override
	public void closeConnection() 
	{
		if(con!=null)
		{
			try 
			{
				con.close();
				System.out.println("Connection to DB closed!");
			} 
			catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		

	}

	@Override
	public boolean setQuery(Customer customer, String query) 
	{
		String SQL="insert into write_to_us_tbl values(?,?,?,?)";
		boolean isAdded=false;
		getConnection();
			try 
			{
				PreparedStatement ps=con.prepareStatement(SQL);
				ps.clearParameters();
				ps.setString(1, customer.getUserName());
				ps.setString(2, query);
				ps.setInt(3, 0);
				ps.setString(4, null);
				
				
				int cnt=ps.executeUpdate();
				if(cnt==1)
				{
					isAdded=true;
					System.out.println("Query Added!");
				}
				else
				{
					System.out.println("Query not Added!");
				}
			} 
			catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally
			{
				closeConnection();
			}
		
		return isAdded;
	}

	@Override
	public ArrayList<WriteToUs> getAllQueries() 
	{
		String SQL="select * from write_to_us_tbl where status=0";
		ArrayList<WriteToUs> queryList=new ArrayList<WriteToUs>();
		WriteToUs writeToUs=null;
		getConnection();
		try 
		{
			PreparedStatement ps=con.prepareStatement(SQL);
			ResultSet rs=ps.executeQuery();
			//Since multiple records are expected we use while
			while(rs.next())
			{
				writeToUs=new WriteToUs();
				
				writeToUs.setUsername(rs.getString("username"));
				writeToUs.setQuery(rs.getString("query"));
				
				queryList.add(writeToUs);
			}
		} 
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			closeConnection();
		}
		return queryList;
	}

	@Override
	public boolean submitAnswer(String userName, String answer) 
	{
		String SQL="update write_to_us_tbl set answer=?,status=1 where username=?";
		boolean isAdded=false;
		getConnection();
			try 
			{
				PreparedStatement ps=con.prepareStatement(SQL);
				ps.clearParameters();
				ps.setString(1, answer);
				ps.setString(2, userName);
				
				int cnt=ps.executeUpdate();
				if(cnt==1)
				{
					isAdded=true;
					System.out.println("Answer submitted!");
				}
				else
				{
					System.out.println("Answer not submitted!");
				}
			} 
			catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally
			{
				closeConnection();
			}
		
		return isAdded;
	}

	@Override
	public ArrayList<WriteToUs> getAnsweredQueries() 
	{
	String SQL="select * from write_to_us_tbl where status=1";
	ArrayList<WriteToUs> answeredQueryList=new ArrayList<WriteToUs>();
	WriteToUs writeToUs=null;
	getConnection();
	try 
	{
		PreparedStatement ps=con.prepareStatement(SQL);
		ResultSet rs=ps.executeQuery();
		//Since multiple records are expected we use while
		while(rs.next())
		{
			writeToUs=new WriteToUs();
			
			
			writeToUs.setQuery(rs.getString("query"));
			writeToUs.setAnswer(rs.getString("answer"));
			
			
			
			answeredQueryList.add(writeToUs);
		}
	} 
	catch (SQLException e) 
	{
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	finally
	{
		closeConnection();
	}
	return answeredQueryList;
	}

}
