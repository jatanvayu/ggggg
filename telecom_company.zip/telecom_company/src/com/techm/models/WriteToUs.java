package com.techm.models;

public class WriteToUs 
{
	private String username;
	private String query;
	private int status;
	private String answer;
	
	public WriteToUs()
	{
		
	}
	
	public WriteToUs(String username, String query, int status, String answer) 
	{
		super();
		this.username = username;
		this.query = query;
		this.status = status;
		this.answer=answer;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	@Override
	public String toString() {
		return "WriteToUs [username=" + username + ", query=" + query
				+ ", status=" + status + ", answer=" + answer + "]";
	}

	
	
	
	

}
