package com.techm.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import com.techm.daos.WriteToUsDAO;

import com.techm.daos.impl.WriteToUsDAOImpl;
import com.techm.models.Customer;

public class QuerySubmitServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	private WriteToUsDAO writeToUsDao;

	public void init(ServletConfig config) throws ServletException 
	{
		System.out.println("QuerySubmitServlet Servlet Init invoked!");
		writeToUsDao=new WriteToUsDAOImpl();
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		System.out.println("QuerySubmitServlet doGet invoked!");
		
		String query=request.getParameter("query");
		System.out.println("query");
		boolean isAdded=false;
		HttpSession session=request.getSession();
		Customer customer=(Customer)session.getAttribute("sessionCustomer");
		isAdded=writeToUsDao.setQuery(customer, query);
		
		
		if(isAdded)
		{
			PrintWriter out=response.getWriter();
			response.setContentType("text/html");
			out.println("<center><h2>Query Submitted!</h2>");
		
			
			RequestDispatcher rd=request.getRequestDispatcher("/login_popup-pack/writetous.jsp");
			rd.include(request,response );
		}
		else
		{
			System.out.println("Query submit Error!");
		}
		
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request,response);
	}

}
