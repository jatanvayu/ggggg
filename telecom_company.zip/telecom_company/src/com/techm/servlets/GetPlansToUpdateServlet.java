package com.techm.servlets;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techm.daos.PlanDAO;
import com.techm.daos.impl.PlanDAOImpl;
import com.techm.models.Plan;


public class GetPlansToUpdateServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	private PlanDAO planDao;


	public void init(ServletConfig config) throws ServletException 
	{
		planDao=new	PlanDAOImpl();
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		HttpSession session=request.getSession();
		ArrayList<Plan> planList=planDao.getAllPlans();
		session.setAttribute("plansToUpdate", planList);
		
		RequestDispatcher rd=request.getRequestDispatcher("/updateplanshome.jsp");
		rd.forward(request,response );
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}

}
