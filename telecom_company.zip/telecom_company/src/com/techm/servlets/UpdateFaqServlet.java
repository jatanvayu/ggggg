package com.techm.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techm.daos.FaqDAO;
import com.techm.daos.impl.FaqDAOImpl;
import com.techm.models.Faq;

public class UpdateFaqServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	private FaqDAO faqDao;

	
	public void init(ServletConfig config) throws ServletException {
		faqDao=new FaqDAOImpl();
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		HttpSession session=request.getSession();
		
		
		Faq faqToUpdate=new Faq();
		faqToUpdate.setFaqId(Integer.parseInt(request.getParameter("id")));
		faqToUpdate.setQuestion(request.getParameter("question"));
		faqDao.updateFaq(faqToUpdate);
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		out.println("<center><h2>FAQ Updated!</h2>");

		RequestDispatcher rd=request.getRequestDispatcher("/updatefaq.jsp");
		rd.include(request,response );
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}

}
