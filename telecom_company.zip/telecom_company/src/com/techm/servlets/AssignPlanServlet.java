package com.techm.servlets;

import java.io.IOException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techm.daos.BillDAO;
import com.techm.daos.impl.BillDAOImpl;
import com.techm.models.Customer;

public class AssignPlanServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	private BillDAO billDao;

	
	public void init(ServletConfig config) throws ServletException 
	{
		billDao=new BillDAOImpl();
		// TODO Auto-generated method stub
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		HttpSession session=request.getSession();
		Customer sessionCustomer=(Customer)session.getAttribute("sessionCustomer");
		String options[]=request.getParameterValues("options");
		billDao.addPlans(sessionCustomer, options);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}

}
