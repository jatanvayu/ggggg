package com.techm.servlets;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techm.daos.FaqDAO;
import com.techm.daos.impl.FaqDAOImpl;
import com.techm.daos.impl.WriteToUsDAOImpl;
import com.techm.models.Faq;

public class DisplayFaqServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	private FaqDAO faqDao;

	
	public void init(ServletConfig config) throws ServletException 
	{
		System.out.println("DisplayFAQServlet Servlet Init invoked!");
		faqDao=new FaqDAOImpl();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		ArrayList<Faq> faqList=faqDao.getAllFaq();
		HttpSession session=request.getSession();
		session.setAttribute("faqList", faqList);
		
		RequestDispatcher rd=request.getRequestDispatcher("/faq.jsp");
		rd.forward(request,response );
	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}

}
